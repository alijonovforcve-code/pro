<?php
/**
 * API controller class for Content Forge plugin.
 *
 * @package ContentForge
 * @since   1.0.0
 */

namespace ContentForge;

use ContentForge\Api\Post;
use ContentForge\Api\Comment;
use ContentForge\Api\User;
use ContentForge\Api\Taxonomy;
use ContentForge\Api\AI;
use ContentForge\Api\Generation_Status;
use ContentForge\Api\Autopilot_Schedules;
use ContentForge\Api\Autopilot_Runs;
use ContentForge\Api\Autopilot_Settings;
use ContentForge\Traits\ContainerTrait;

class Api {

	use ContainerTrait;

	/**
	 * Api constructor.
	 */
	public function __construct()
	{
		$this->container['post']              = new Post();
		$this->container['comment']           = new Comment();
		$this->container['user']              = new User();
		$this->container['taxonomy']          = new Taxonomy();
		$this->container['ai']                = new AI();
		$this->container['generation_status'] = new Generation_Status();
		$this->container['autopilot_schedules'] = new Autopilot_Schedules();
		$this->container['autopilot_runs']      = new Autopilot_Runs();
		$this->container['autopilot_settings']  = new Autopilot_Settings();

		add_action( 'rest_api_init', [ $this, 'init_api' ] );
	}

	/**
	 * Initialize API
	 *
	 * @since 2.0.0
	 *
	 * @return void
	 */
	public function init_api()
	{
		foreach ( $this->container as $class ) {
			$object = new $class();
			$object->register_routes();
		}
	}
}
