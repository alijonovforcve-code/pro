<?php
$langpref = 'en.php';
?>