<?php

$LANG = array(

'L_SAVE_SUCCESSFUL'			=> 'Daten erfolgreich gespeichert',
'L_UPDATE_TITLE'			=> 'Aktualisierung PluXml',
'L_WRONG_PHP_VERSION'		=> 'PluXml benötigt mindestens PHP 5 um zu funktionieren.',

'L_SELECT_LANG'				=> 'Wählen Sie Ihre Sprache',
'L_INPUT_CHANGE'			=> 'Ändern',

'L_UPDATE_UPTODATE'			=> 'Ihre PluXml ist bereits aktualisiert.',
'L_UPDATE_NOT_AVAILABLE'		=> 'Es gibt keine Aktualisierung.',
'L_UPDATE_BACK'				=> 'Zurück zur Website',
'L_UPDATE_WARNING1'			=> 'Ihr altes PluXml wird aktualisiert.',
'L_UPDATE_SELECT_VERSION'	=> 'Wählen Sie Ihre alte PluXml Version.',
'L_UPDATE_WARNING2'			=> 'Wenn Ihre alte PluXml Version nicht angezeigt wird, ist sie zu alt.<br />Wir empfehlen Ihnen die neuste Version von <a href="https://www.pluxml.org">PluXml</a> zu laden und neu zu installieren.',
'L_UPDATE_WARNING3'			=> 'Warnung: Vergessen Sie nicht, vor der Aktualisierung das Verzeichnis "%s" zu sichern.',
'L_UPDATE_START'			=> 'Aktualisierung starten',

'L_UPDATE_ENDED'			=> 'Aktualisierung der Version %s beendet.',
'L_UPDATE_INPROGRESS'		=> 'Updating version',
'L_UPDATE_ERROR'			=> 'Ein Fehler der Aktualisierung ist aufgetreten.',
'L_UPDATE_SUCCESSFUL'		=> 'Alle Aktualisierungen wurden erfolgreich durchgeführt!',

'L_UPDATE_UPDATE_PARAMETERS_FILE'	=> 'Aktualisierung der Datei parametres.xml',
'L_UPDATE_CREATE_TAGS_FILE'			=> 'Dateierstellung tags.xml',
'L_UPDATE_ERR_CREATE_TAGS_FILE'		=> 'Fehler der Dateierstellung tags.xml',
'L_UPDATE_CREATE_THEME_FILE'		=> 'Dateierstellung theme',
'L_UPDATE_ERR_CREATE_THEME_FILE'	=> 'Fehler der Dateierstellung',
'L_UPDATE_ARTICLES_CONVERSION'		=> 'Artikelkonvertierung',
'L_UPDATE_ERR_FILE_PROCESSING'		=> 'Fehler der Dateiverarbeitung',
'L_UPDATE_STATICS_MIGRATION'		=> 'Dateiverarbeitung der statischen Seiten',
'L_UPDATE_ERR_STATICS_MIGRATION'	=> 'Fehler der Dateiverarbeitung der statischen Seiten',
'L_UPDATE_CREATE_USERS_FILE'		=> 'Dateierstellung der Benutzer',
'L_UPDATE_ERR_CREATE_USERS_FILE'	=> 'Fehler der Dateierstellung der Benutzer',
'L_UPDATE_USERS_MIGRATION'			=> 'Dateiverarbeitung der Benutzer',
'L_UPDATE_ERR_USERS_MIGRATION'		=> 'Fehler der Dateiverarbeitung der Benutzer',
'L_UPDATE_ERR_NO_USERS'				=> 'Es gibt keine Benutzer',
'L_UPDATE_CREATE_HTACCESS_FILE'		=> 'Dateierstellung .htaccess',
'L_UPDATE_ERR_CREATE_HTACCESS_FILE'	=> 'Fehler der Dateierstellung .htaccess',
'L_UPDATE_UPDATE_HTACCESS_FILE'		=> 'Aktualisieren Sie die Datei .htaccess',
'L_UPDATE_ERR_UPDATE_HTACCESS_FILE'	=> 'Fehler beim Aktualisieren der Datei .htaccess',
'L_UPDATE_CATEGORIES_MIGRATION'		=> 'Dateiverarbeitung der Kategorien',
'L_UPDATE_ERR_CATEGORIES_MIGRATION'	=> 'Fehler der Dateiverarbeitung der Kategorien',
'L_UPDATE_CREATE_PLUGINS_FILE'		=> 'Dateierstellung plugins.xml',
'L_UPDATE_ERR_CREATE_PLUGINS_FILE'	=> 'Fehler beim Löschen von plugins.xml',
'L_UPDATE_DELETE_FULLSCREEN_FILE'	=> 'Dateilöschung core/admin/fullscreen.php',
'L_UPDATE_ERR_DELETE_FULLSCREEN_FILE'   => 'Fehler beim Löschen von core/admin/fullscreen.php',
'L_UPDATE_DELETE_PLXTOOLBAR_FOLDER'	=>	'Dateilöschung core/plxtoolbar/',
'L_UPDATE_ERR_DELETE_PLXTOOLBAR_FOLDER' => 'Fehler der Dateilöschung core/plxtoolbar/',
'L_UPDATE_FILE'						=> 'Update Datei',
'L_UPDATE_ERR_FILE'					=> 'Fehler während des Dateiupdates',
'L_UPDATE_PLUG_MOVEPARAMFILE'		=> 'Migration Plugin-Einstellungen im Konfigurationverzeichnis',
'L_UPDATE_UPDATE_PLUGINS_FILE'		=> 'Aktualisierung der Datei plugins.xml',
'L_UPDATE_COMMENTS_MIGRATION'		=> 'Migration Kommentare',
'L_UPDATE_ERR_COMMENTS_MIGRATION'	=> 'Fehler beim Migrieren der Kommentare',

# PluXml 5.8.7
'L_BUILD_CSS_PLUGINS_CACHE'			=> 'Erstellung von admin.css und site.css Cache-Dateien für Plugins',
);

